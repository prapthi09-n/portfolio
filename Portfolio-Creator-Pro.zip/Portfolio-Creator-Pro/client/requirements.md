## Packages
framer-motion | Complex animations and page transitions
react-icons | Popular icon sets including FontAwesome, Material Design, etc.
react-hook-form | Form state management
@hookform/resolvers | Validation resolvers for react-hook-form
zod | Schema validation

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  display: ["'Outfit'", "sans-serif"],
  body: ["'DM Sans'", "sans-serif"],
  mono: ["'JetBrains Mono'", "monospace"],
}
