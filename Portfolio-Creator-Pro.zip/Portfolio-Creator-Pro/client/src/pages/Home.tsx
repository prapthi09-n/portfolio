import { motion } from "framer-motion";
import { Link } from "wouter";
import { ArrowRight, Download, Github, Linkedin, Mail } from "lucide-react";

export default function Home() {
  return (
    <div className="min-h-screen flex flex-col justify-center relative overflow-hidden pt-16">
      {/* Abstract Background Blobs */}
      <div className="absolute top-[-20%] right-[-10%] w-[500px] h-[500px] bg-primary/20 rounded-full blur-[120px] pointer-events-none mix-blend-screen animate-pulse" />
      <div className="absolute bottom-[-20%] left-[-10%] w-[500px] h-[500px] bg-secondary/20 rounded-full blur-[120px] pointer-events-none mix-blend-screen" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 w-full">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
          >
            <div className="inline-block px-3 py-1 rounded-full border border-primary/30 bg-primary/10 text-primary text-sm font-semibold mb-6">
              AI/ML Engineering Student
            </div>
            
            <h1 className="text-5xl md:text-7xl font-bold font-display leading-tight mb-6">
              Hello, I'm <br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary via-purple-400 to-secondary animate-gradient">
                Prapthi N
              </span>
            </h1>
            
            <p className="text-xl text-muted-foreground font-body max-w-lg mb-8 leading-relaxed">
              Passionate about building intelligent systems and solving complex problems with code. Based in Mysuru, India.
            </p>
            
            <div className="flex flex-wrap gap-4 mb-10">
              <Link href="/contact">
                <button className="px-8 py-4 rounded-xl font-bold bg-white text-black hover:scale-105 active:scale-95 transition-all duration-200 flex items-center gap-2 shadow-[0_0_20px_-5px_rgba(255,255,255,0.3)]">
                  Contact Me <ArrowRight size={20} />
                </button>
              </Link>
              
              <button className="px-8 py-4 rounded-xl font-bold glass-card text-white hover:bg-white/10 hover:border-white/20 transition-all duration-200 flex items-center gap-2">
                Download Resume <Download size={20} />
              </button>
            </div>

            <div className="flex gap-6">
              <SocialIcon href="https://linkedin.com/in/prapthi-n" icon={<Linkedin />} />
              <SocialIcon href="mailto:nprapthi2005@gmail.com" icon={<Mail />} />
              <SocialIcon href="https://github.com" icon={<Github />} />
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="relative hidden lg:block"
          >
            <div className="relative w-full aspect-square max-w-md mx-auto">
              {/* Decorative Circle Rings */}
              <div className="absolute inset-0 border border-white/5 rounded-full animate-[spin_10s_linear_infinite]" />
              <div className="absolute inset-4 border border-white/5 rounded-full animate-[spin_15s_linear_infinite_reverse]" />
              <div className="absolute inset-8 border border-white/5 rounded-full" />
              
              {/* Image Placeholder with Neon Glow */}
              <div className="absolute inset-10 rounded-full overflow-hidden border-2 border-white/10 bg-black/50 shadow-[0_0_50px_-10px_rgba(124,58,237,0.3)]">
                {/* 
                  Technology abstract image
                  Unsplash: Artificial Intelligence abstract node network 
                */}
                <img 
                  src="https://images.unsplash.com/photo-1620712943543-bcc4688e7485?w=800&q=80" 
                  alt="Profile Visual" 
                  className="w-full h-full object-cover opacity-80 hover:opacity-100 transition-opacity duration-500 hover:scale-110 transform"
                />
              </div>

              {/* Floating Badge 1 */}
              <motion.div 
                animate={{ y: [0, -10, 0] }}
                transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
                className="absolute top-20 right-0 glass-card px-4 py-2 rounded-lg text-sm font-mono border-l-4 border-l-secondary"
              >
                AI/ML Enthusiast
              </motion.div>

              {/* Floating Badge 2 */}
              <motion.div 
                animate={{ y: [0, 10, 0] }}
                transition={{ duration: 5, repeat: Infinity, ease: "easeInOut", delay: 1 }}
                className="absolute bottom-20 left-0 glass-card px-4 py-2 rounded-lg text-sm font-mono border-l-4 border-l-primary"
              >
                Java Developer
              </motion.div>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
}

function SocialIcon({ href, icon }: { href: string; icon: React.ReactNode }) {
  return (
    <a
      href={href}
      target="_blank"
      rel="noopener noreferrer"
      className="p-3 rounded-full bg-white/5 border border-white/10 hover:bg-white/10 hover:scale-110 hover:border-primary/50 transition-all duration-300 text-muted-foreground hover:text-primary shadow-lg hover:shadow-primary/20"
    >
      {icon}
    </a>
  );
}
