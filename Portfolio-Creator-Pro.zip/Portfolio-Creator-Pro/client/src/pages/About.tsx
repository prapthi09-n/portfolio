import { motion } from "framer-motion";
import { User, MapPin, Calendar, BookOpen } from "lucide-react";

export default function About() {
  return (
    <div className="min-h-screen pt-24 pb-12 relative overflow-hidden">
      {/* Background accents */}
      <div className="absolute top-0 left-1/4 w-[500px] h-[500px] bg-primary/10 rounded-full blur-[100px] pointer-events-none" />
      
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-display font-bold mb-4">About Me</h2>
          <div className="w-24 h-1 bg-gradient-to-r from-primary to-secondary mx-auto rounded-full" />
        </motion.div>

        <div className="grid md:grid-cols-3 gap-8 mb-16">
          {/* Main Bio Card */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="md:col-span-2 glass-card rounded-2xl p-8 border-l-4 border-l-primary"
          >
            <h3 className="text-2xl font-bold mb-6 flex items-center gap-2">
              <User className="text-primary" /> Biography
            </h3>
            <p className="text-muted-foreground leading-relaxed text-lg mb-6">
              I am an engineering student specializing in Computer Science with a focus on Artificial Intelligence and Machine Learning. 
              My academic journey is driven by a curiosity to understand how intelligent systems can solve real-world problems.
            </p>
            <p className="text-muted-foreground leading-relaxed text-lg">
              Currently studying at Maharaja Institute of Technology Mysore, I balance my technical pursuits with strong communication 
              and collaboration skills, always eager to learn and contribute to innovative projects.
            </p>
          </motion.div>

          {/* Quick Stats Card */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="glass-card rounded-2xl p-8 flex flex-col justify-center gap-6"
          >
            <div className="flex items-start gap-4">
              <div className="p-3 rounded-lg bg-secondary/10 text-secondary">
                <MapPin size={24} />
              </div>
              <div>
                <h4 className="font-bold text-lg">Location</h4>
                <p className="text-muted-foreground">Mysuru, Karnataka</p>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <div className="p-3 rounded-lg bg-accent/10 text-accent">
                <BookOpen size={24} />
              </div>
              <div>
                <h4 className="font-bold text-lg">Degree</h4>
                <p className="text-muted-foreground">BE (CSE - AI/ML)</p>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <div className="p-3 rounded-lg bg-primary/10 text-primary">
                <Calendar size={24} />
              </div>
              <div>
                <h4 className="font-bold text-lg">Grad Year</h4>
                <p className="text-muted-foreground">2027 (Expected)</p>
              </div>
            </div>
          </motion.div>
        </div>

        {/* Timeline Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.3 }}
        >
          <h3 className="text-2xl font-bold mb-8 text-center">My Journey</h3>
          
          <div className="relative border-l-2 border-white/10 ml-6 md:ml-12 space-y-12">
            <TimelineItem 
              year="2023 - Present"
              title="BE in Computer Science (AI/ML)"
              place="Maharaja Institute of Technology Mysore"
              description="Current CGPA: 7.91. Focusing on core CS concepts and specialized AI/ML coursework."
            />
            <TimelineItem 
              year="2021 - 2023"
              title="Pre-University (PCMB)"
              place="Sadhvidya Composite PU College"
              description="Completed with 85%. Developed strong analytical and scientific foundations."
            />
            <TimelineItem 
              year="2020"
              title="SSLC (Secondary School)"
              place="Hari Vidyalaya"
              description="Completed with 71%. Built early interest in mathematics and science."
            />
          </div>
        </motion.div>
      </div>
    </div>
  );
}

function TimelineItem({ year, title, place, description }: { year: string, title: string, place: string, description: string }) {
  return (
    <div className="relative pl-8 md:pl-12 group">
      {/* Dot */}
      <div className="absolute -left-[9px] top-0 w-4 h-4 rounded-full bg-background border-2 border-primary group-hover:bg-primary group-hover:scale-125 transition-all duration-300 shadow-[0_0_10px_rgba(124,58,237,0.5)]" />
      
      <div className="glass-card p-6 rounded-xl hover:bg-white/5 transition-colors border-l-0">
        <span className="text-sm font-mono text-secondary mb-2 block">{year}</span>
        <h4 className="text-xl font-bold text-white mb-1">{title}</h4>
        <h5 className="text-lg text-primary/80 mb-3">{place}</h5>
        <p className="text-muted-foreground text-sm leading-relaxed">{description}</p>
      </div>
    </div>
  );
}
