import { motion } from "framer-motion";
import { ArrowUpRight, Github, Activity, Home } from "lucide-react";

export default function Projects() {
  const projects = [
    {
      title: "House Price Prediction",
      description: "A machine learning model built to analyze housing data and predict market prices with high accuracy. Implemented using Python and regression algorithms.",
      tech: ["Python", "Machine Learning", "Scikit-Learn", "Pandas"],
      icon: <Home size={32} />,
      gradient: "from-blue-500 to-cyan-500",
      image: "https://images.unsplash.com/photo-1560518883-ce09059eeffa?w=800&q=80" // Modern architecture building
    },
    {
      title: "Radar System Simulation",
      description: "An embedded systems prototype using Arduino and ultrasonic sensors to detect objects and map their distance and angle in real-time, simulating radar technology.",
      tech: ["Arduino", "C++", "Sensors", "Hardware Interface"],
      icon: <Activity size={32} />,
      gradient: "from-purple-500 to-pink-500",
      image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=800&q=80" // Data visualization / radar screen
    }
  ];

  return (
    <div className="min-h-screen pt-24 pb-12 relative overflow-hidden">
      {/* Background blobs */}
      <div className="absolute top-1/3 left-0 w-[500px] h-[500px] bg-primary/10 rounded-full blur-[120px] pointer-events-none" />
      <div className="absolute bottom-0 right-0 w-[500px] h-[500px] bg-secondary/10 rounded-full blur-[120px] pointer-events-none" />

      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-display font-bold mb-4">Featured Projects</h2>
          <p className="text-muted-foreground text-lg">
            A showcase of my technical applications in AI/ML and embedded systems.
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-8">
          {projects.map((project, index) => (
            <ProjectCard key={index} project={project} index={index} />
          ))}
        </div>
      </div>
    </div>
  );
}

function ProjectCard({ project, index }: { project: any, index: number }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 40 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.6, delay: index * 0.2 }}
      className="group relative h-full"
    >
      <div className="glass-card rounded-3xl overflow-hidden h-full flex flex-col border border-white/10 hover:border-white/20 transition-all duration-300">
        {/* Image Area with Overlay */}
        <div className="relative h-64 overflow-hidden">
          <div className={`absolute inset-0 bg-gradient-to-br ${project.gradient} opacity-20 group-hover:opacity-10 transition-opacity duration-500 z-10`} />
          <div className="absolute inset-0 bg-black/40 z-0" />
          
          {/* Unsplash Image */}
          <img 
            src={project.image} 
            alt={project.title}
            className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-700 ease-in-out"
          />

          <div className="absolute top-4 right-4 z-20">
             <div className="p-2 bg-black/50 backdrop-blur-md rounded-full border border-white/10 text-white">
               <ArrowUpRight size={20} />
             </div>
          </div>
          
          <div className="absolute bottom-4 left-4 z-20 p-3 bg-black/60 backdrop-blur-xl rounded-xl border border-white/10 text-white">
            {project.icon}
          </div>
        </div>

        {/* Content Area */}
        <div className="p-8 flex-1 flex flex-col">
          <h3 className="text-2xl font-bold mb-3 font-display group-hover:text-primary transition-colors">
            {project.title}
          </h3>
          <p className="text-muted-foreground leading-relaxed mb-6 flex-1">
            {project.description}
          </p>

          <div className="flex flex-wrap gap-2 mt-auto">
            {project.tech.map((tag: string, i: number) => (
              <span 
                key={i} 
                className="px-3 py-1 rounded-full text-xs font-semibold bg-white/5 border border-white/10 text-white/80"
              >
                {tag}
              </span>
            ))}
          </div>

          <div className="flex gap-4 mt-8 pt-6 border-t border-white/5">
            <button className="flex items-center gap-2 text-sm font-bold text-white hover:text-primary transition-colors">
              <Github size={18} /> View Code
            </button>
            <button className="flex items-center gap-2 text-sm font-bold text-white hover:text-secondary transition-colors">
              Live Demo <ArrowUpRight size={18} />
            </button>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
