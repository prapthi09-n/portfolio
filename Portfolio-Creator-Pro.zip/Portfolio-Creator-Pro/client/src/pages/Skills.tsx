import { motion } from "framer-motion";
import { Code2, Terminal, Database, Cpu, MessageCircle, Users } from "lucide-react";

export default function Skills() {
  const technicalSkills = [
    { name: "C Programming", icon: <Terminal size={24} />, color: "text-blue-400", bg: "bg-blue-500/10", border: "border-blue-500/20" },
    { name: "Python", icon: <Code2 size={24} />, color: "text-yellow-400", bg: "bg-yellow-500/10", border: "border-yellow-500/20" },
    { name: "Java", icon: <Cpu size={24} />, color: "text-red-400", bg: "bg-red-500/10", border: "border-red-500/20" },
    { name: "MongoDB", icon: <Database size={24} />, color: "text-green-400", bg: "bg-green-500/10", border: "border-green-500/20" },
  ];

  const softSkills = [
    { name: "Communication", icon: <MessageCircle size={24} />, color: "text-purple-400", bg: "bg-purple-500/10", border: "border-purple-500/20" },
    { name: "Team Collaboration", icon: <Users size={24} />, color: "text-pink-400", bg: "bg-pink-500/10", border: "border-pink-500/20" },
  ];

  return (
    <div className="min-h-screen pt-24 pb-12 relative overflow-hidden">
      <div className="absolute bottom-0 right-1/4 w-[600px] h-[600px] bg-secondary/10 rounded-full blur-[120px] pointer-events-none" />

      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-display font-bold mb-4">Skills & Expertise</h2>
          <p className="text-muted-foreground max-w-xl mx-auto">
            A combination of technical proficiency and interpersonal strengths that allow me to contribute effectively to any team.
          </p>
        </motion.div>

        <div className="mb-20">
          <h3 className="text-2xl font-bold mb-8 pl-4 border-l-4 border-primary">Technical Proficiency</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {technicalSkills.map((skill, index) => (
              <SkillCard key={index} skill={skill} index={index} />
            ))}
          </div>
        </div>

        <div>
          <h3 className="text-2xl font-bold mb-8 pl-4 border-l-4 border-secondary">Soft Skills</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            {softSkills.map((skill, index) => (
              <SkillCard key={index} skill={skill} index={index + 4} />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

function SkillCard({ skill, index }: { skill: any, index: number }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ delay: index * 0.1 }}
      whileHover={{ y: -5, scale: 1.02 }}
      className={`glass-card p-6 rounded-2xl border ${skill.border} hover:bg-white/5 transition-all duration-300 group`}
    >
      <div className={`w-12 h-12 rounded-xl ${skill.bg} ${skill.color} flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300`}>
        {skill.icon}
      </div>
      <h4 className="text-xl font-bold text-foreground mb-2">{skill.name}</h4>
      <div className="h-1.5 w-full bg-white/5 rounded-full overflow-hidden mt-4">
        <motion.div 
          initial={{ width: 0 }}
          whileInView={{ width: "85%" }}
          viewport={{ once: true }}
          transition={{ duration: 1, delay: 0.5 + (index * 0.1) }}
          className={`h-full ${skill.color.replace('text', 'bg')}`} 
        />
      </div>
    </motion.div>
  );
}
