import { motion } from "framer-motion";
import { GraduationCap, Award, Book } from "lucide-react";

export default function Education() {
  const education = [
    {
      year: "2023 - 2027 (Expected)",
      degree: "Bachelor of Engineering",
      major: "Computer Science and Engineering (AI/ML)",
      institution: "Maharaja Institute of Technology Mysore",
      score: "CGPA: 7.91",
      icon: <GraduationCap className="w-6 h-6" />,
      color: "bg-purple-500"
    },
    {
      year: "2021 - 2023",
      degree: "Pre-University Course",
      major: "PCMB (Physics, Chemistry, Mathematics, Biology)",
      institution: "Sadhvidya Composite PU College",
      score: "Score: 85%",
      icon: <Book className="w-6 h-6" />,
      color: "bg-cyan-500"
    },
    {
      year: "2020",
      degree: "Secondary School Leaving Certificate",
      major: "General Education",
      institution: "Hari Vidyalaya",
      score: "Score: 71%",
      icon: <Award className="w-6 h-6" />,
      color: "bg-pink-500"
    }
  ];

  return (
    <div className="min-h-screen pt-24 pb-12 relative overflow-hidden">
       {/* Background */}
       <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-primary/5 rounded-full blur-[150px] pointer-events-none" />

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-display font-bold mb-4">Academic History</h2>
          <p className="text-muted-foreground text-lg">My educational background and qualifications.</p>
        </motion.div>

        <div className="space-y-8">
          {education.map((item, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, x: index % 2 === 0 ? -50 : 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              className="glass-card rounded-2xl p-8 hover:bg-white/5 transition-all duration-300 relative group overflow-hidden"
            >
              {/* Decorative side bar */}
              <div className={`absolute left-0 top-0 bottom-0 w-2 ${item.color} group-hover:w-3 transition-all duration-300`} />
              
              <div className="flex flex-col md:flex-row gap-6 items-start">
                <div className={`shrink-0 w-12 h-12 rounded-full ${item.color}/20 flex items-center justify-center text-white border border-white/10 group-hover:scale-110 transition-transform duration-300`}>
                  {item.icon}
                </div>
                
                <div className="flex-1">
                  <div className="flex flex-col md:flex-row md:justify-between md:items-center mb-2">
                    <h3 className="text-2xl font-bold font-display">{item.degree}</h3>
                    <span className="inline-block px-3 py-1 rounded-full bg-white/5 border border-white/10 text-sm font-mono text-primary mt-2 md:mt-0">
                      {item.year}
                    </span>
                  </div>
                  
                  <h4 className="text-lg text-secondary font-medium mb-1">{item.major}</h4>
                  <p className="text-lg text-muted-foreground mb-4">{item.institution}</p>
                  
                  <div className="inline-block px-4 py-2 rounded-lg bg-white/5 border border-white/10 font-bold text-white shadow-sm">
                    {item.score}
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}
