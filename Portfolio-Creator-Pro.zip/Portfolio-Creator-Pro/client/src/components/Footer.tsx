import { Github, Linkedin, Mail } from "lucide-react";

export default function Footer() {
  return (
    <footer className="w-full py-8 mt-20 border-t border-white/5 bg-black/20 backdrop-blur-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row justify-between items-center gap-4">
        <p className="text-muted-foreground text-sm font-body">
          © {new Date().getFullYear()} Prapthi N. All rights reserved.
        </p>
        
        <div className="flex space-x-6">
          <a
            href="https://linkedin.com/in/prapthi-n"
            target="_blank"
            rel="noopener noreferrer"
            className="text-muted-foreground hover:text-primary transition-colors hover:scale-110 transform duration-200"
          >
            <Linkedin size={20} />
          </a>
          <a
            href="mailto:nprapthi2005@gmail.com"
            className="text-muted-foreground hover:text-secondary transition-colors hover:scale-110 transform duration-200"
          >
            <Mail size={20} />
          </a>
          <a
            href="https://github.com"
            target="_blank"
            rel="noopener noreferrer"
            className="text-muted-foreground hover:text-white transition-colors hover:scale-110 transform duration-200"
          >
            <Github size={20} />
          </a>
        </div>
      </div>
    </footer>
  );
}
